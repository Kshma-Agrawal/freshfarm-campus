UI design files and user flows will be stored here.
