Project documentation files will be stored here.
